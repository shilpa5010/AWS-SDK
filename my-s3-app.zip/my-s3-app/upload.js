// Import the necessary AWS SDK clients and commands
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const fs = require("fs");
const path = require("path");

// Create an S3 client
const s3Client = new S3Client({ region: "us-east-1" }); // Change region as needed

// Define the parameters for the upload
const bucketName = "files-upload-js"; // Replace with your bucket name
const fileName = "example.txt"; // Replace with your file name
const filePath = path.join(__dirname, fileName); // Path to the file
console.log(filePath)
const uploadFile = async () => {
  try {
    // Read the file content
    const fileContent = fs.readFileSync(filePath);

    // Set up the upload parameters
    const uploadParams = {
      Bucket: bucketName,
      Key: fileName,
      Body: fileContent,
    };

    // Upload the file
    console.log(new PutObjectCommand(uploadParams))
    const data = await s3Client.send(new PutObjectCommand(uploadParams));
    console.log(data)
    console.log("File uploaded successfully. Location:", data.Location);
  } catch (error) {
    console.error("Error uploading file:", error);
  }
};

// Call the upload function
uploadFile();
